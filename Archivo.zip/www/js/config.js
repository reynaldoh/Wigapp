/*Driver App Configuration*/

var Wigoo_driver_config ={			
	'ApiUrl':"https://wigoo.co/driver/api",		
	'DialogDefaultTitle':"DriverApp",
	'mapboxToken' : '',
	'APIHasKey':"reyh0400",
	'debug': true
};